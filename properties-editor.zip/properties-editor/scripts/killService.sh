#!/bin/sh

stop_service() 
{
    cd ${HOME}
    ${HOME}/service/killService.sh
}

main()
{
    stop_service $*
}

main $*
